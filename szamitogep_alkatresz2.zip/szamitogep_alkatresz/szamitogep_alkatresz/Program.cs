﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

class Program
{
    // a fálj elérési útja
    private const string FilePath = "parts.txt";

    // alkatrészek listájának létrehozása
    private static List<ComputerPart> parts = new List<ComputerPart>();

    // adatok tárolására
    class ComputerPart
    {
        public string Type { get; set; }
        public string Name { get; set; }
        public string Parameters { get; set; }
        public decimal Price { get; set; }

        public override string ToString()
        {
            return $"{Type};{Name};{Parameters};{Price}";
        }
    }

    static void Main(string[] args)
    {
        // Alkatrészek betöltése
        LoadParts();

        while (true)
        {
            //opciók megjelenítése
            Console.WriteLine("\n1. Új alkatrész hozzáadása");
            Console.WriteLine("2. Keresés típus/név alapján");
            Console.WriteLine("3. Keresés árkategória alapján");
            Console.WriteLine("4. Statisztika megjelenítése");
            Console.WriteLine("5. Akció alkalmazása");
            Console.WriteLine("6. Kilépés");

            var choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    AddNewPart();
                    break;
                case "2":
                    SearchByTypeOrName();
                    break;
                case "3":
                    SearchByPriceRange();
                    break;
                case "4":
                    ShowStatistics();
                    break;
                case "5":
                    ApplyDiscount();
                    break;
                case "6":
                    return;
            }
        }
    }

    static void LoadParts()
    {
        if (File.Exists(FilePath))
        {
            try
            {
                var lines = File.ReadAllLines(FilePath);
                foreach (var line in lines)
                {
                    // Az alkatrész adatainak szétválasztása
                    var data = line.Split(';');
                    if (data.Length == 4) // Ellenőrzés
                    {
                        parts.Add(new ComputerPart
                        {
                            Type = data[0],
                            Name = data[1],
                            Parameters = data[2],
                            Price = decimal.Parse(data[3])
                        });
                    }
                    else
                    {
                        Console.WriteLine($"Hibás sor a fájlban: {line}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba történt az alkatrészek betöltésekor: {ex.Message}");
            }
        }
        else
        {
            Console.WriteLine("A parts.txt fájl nem található!");
        }
    }

    // Az alkatrészek mentése
    static void SaveParts()
    {
        try
        {
            File.WriteAllLines(FilePath, parts.Select(p => p.ToString()));
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Hiba történt az adatok mentésekor: {ex.Message}");
        }
    }

    // Új alkatrész hozzáadása a listához
    static void AddNewPart()
    {
        var part = new ComputerPart();

        Console.Write("Típus (pl. CPU, GPU, RAM): ");
        part.Type = Console.ReadLine();

        Console.Write("Név: ");
        part.Name = Console.ReadLine();

        Console.Write("Paraméterek: ");
        part.Parameters = Console.ReadLine();

        Console.Write("Ár (Ft): ");
        if (decimal.TryParse(Console.ReadLine(), out var price))
        {
            part.Price = price;

            //alkatrész hozzáadása és mentés 
            parts.Add(part);
            SaveParts();
            Console.WriteLine("Alkatrész sikeresen hozzáadva!");
        }
        else
        {
            Console.WriteLine("Hibás ár formátum! Próbáld újra.");
        }
    }

    // Keresés típus vagy név alapján
    static void SearchByTypeOrName()
    {
        Console.Write("Keresett kifejezés: ");
        var query = Console.ReadLine().ToLower();

        var results = parts.Where(p =>
            p.Type.ToLower().Contains(query) ||
            p.Name.ToLower().Contains(query));

        DisplayResults(results);
    }

    // Keresés árkategória alapján
    static void SearchByPriceRange()
    {
        Console.Write("Minimum ár (Ft): ");
        if (decimal.TryParse(Console.ReadLine(), out var minPrice))
        {
            Console.Write("Maximum ár (Ft): ");
            if (decimal.TryParse(Console.ReadLine(), out var maxPrice))
            {
                var results = parts.Where(p => p.Price >= minPrice && p.Price <= maxPrice);
                DisplayResults(results);
            }
            else
            {
                Console.WriteLine("Hibás maximum ár formátum!");
            }
        }
        else
        {
            Console.WriteLine("Hibás minimum ár formátum!");
        }
    }

    // Statisztika készítése
    static void ShowStatistics()
    {
        Console.Write("Alkatrész típusa (pl. CPU, GPU): ");
        var type = Console.ReadLine().ToUpper();

        var typeStats = parts
            .Where(p => p.Type.ToUpper() == type)
            .GroupBy(p => p.Name.Split(' ')[0])
            .ToDictionary(g => g.Key, g => g.Count());

        Console.WriteLine($"\nStatisztika {type} típushoz:");
        foreach (var stat in typeStats)
        {
            Console.WriteLine($"{stat.Key}: {stat.Value} db");
        }
    }

    // Kedvezmény alkalmazása
    static void ApplyDiscount()
    {
        Console.Write("Alkatrész típusa (vagy MIND minden termékhez): ");
        var type = Console.ReadLine().ToUpper();

        Console.Write("Kedvezmény százalékban: ");
        if (decimal.TryParse(Console.ReadLine(), out var discount))
        {
            foreach (var part in parts)
            {
                if (type == "MIND" || part.Type.ToUpper() == type)
                {
                    part.Price = part.Price * (1 - discount / 100);
                }
            }
            SaveParts();
            Console.WriteLine("Kedvezmény sikeresen alkalmazva!");
        }
        else
        {
            Console.WriteLine("Hibás kedvezmény formátum!");
        }
    }

    // Keresési találatok megjelenítése
    static void DisplayResults(IEnumerable<ComputerPart> results)
    {
        Console.WriteLine("\nTalált alkatrészek:");
        foreach (var part in results)
        {
            Console.WriteLine($"Típus: {part.Type}, Név: {part.Name}, " +
                            $"Paraméterek: {part.Parameters}, Ár: {part.Price:N0} Ft");
        }
    }
}
