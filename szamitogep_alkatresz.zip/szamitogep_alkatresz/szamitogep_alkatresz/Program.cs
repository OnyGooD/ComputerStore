﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

class Program
{
    // Az alkatrészeket tartalmazó fájl elérési útja
    private const string FilePath = "parts.txt";

    // Az alkatrészek listája a program futása során
    private static List<ComputerPart> parts = new List<ComputerPart>();

    // Osztály egy számítógépes alkatrész adatainak tárolására
    class ComputerPart
    {
        public string Type { get; set; } 
        public string Name { get; set; } 
        public string Parameters { get; set; } 
        public decimal Price { get; set; } 

        
        public override string ToString()
        {
            return $"{Type};{Name};{Parameters};{Price}";
        }
    }

   
    static void Main(string[] args)
    {
        // Alkatrészek betöltése fájlból
        LoadParts();

        
        while (true)
        {
            // Menü opciók megjelenítése
            Console.WriteLine("\n1. Új alkatrész hozzáadása");
            Console.WriteLine("2. Keresés típus/név alapján");
            Console.WriteLine("3. Keresés árkategória alapján");
            Console.WriteLine("4. Statisztika megjelenítése");
            Console.WriteLine("5. Akció alkalmazása");
            Console.WriteLine("6. Kilépés");

            
            var choice = Console.ReadLine();

            
            switch (choice)
            {
                case "1":
                    AddNewPart();
                    break;
                case "2":
                    SearchByTypeOrName();
                    break;
                case "3":
                    SearchByPriceRange();
                    break;
                case "4":
                    ShowStatistics();
                    break;
                case "5":
                    ApplyDiscount();
                    break;
                case "6":
                    return;
            }
        }
    }

    // Alkatrészek betöltése a fájlból a memóriába
    static void LoadParts()
    {
        if (File.Exists(FilePath))
        {
            var lines = File.ReadAllLines(FilePath);
            foreach (var line in lines)
            {
                // Az alkatrész adatainak szétválasztása
                var data = line.Split(';');
                parts.Add(new ComputerPart
                {
                    Type = data[0],
                    Name = data[1],
                    Parameters = data[2],
                    Price = decimal.Parse(data[3])
                });
            }
        }
    }

    // Az alkatrészek listájának mentése a fájlba
    static void SaveParts()
    {
        File.WriteAllLines(FilePath, parts.Select(p => p.ToString()));
    }

    // Új alkatrész hozzáadása a listához
    static void AddNewPart()
    {
        var part = new ComputerPart();

        
        Console.Write("Típus (pl. CPU, GPU, RAM): ");
        part.Type = Console.ReadLine();

        Console.Write("Név: ");
        part.Name = Console.ReadLine();

        Console.Write("Paraméterek: ");
        part.Parameters = Console.ReadLine();

        Console.Write("Ár (Ft): ");
        part.Price = decimal.Parse(Console.ReadLine());

        // Az alkatrész hozzáadása a listához és mentés fájlba
        parts.Add(part);
        SaveParts();
        Console.WriteLine("Alkatrész sikeresen hozzáadva!");
    }

    // Keresés típus vagy név alapján
    static void SearchByTypeOrName()
    {
        Console.Write("Keresett kifejezés: ");
        var query = Console.ReadLine().ToLower();

        
        var results = parts.Where(p =>
            p.Type.ToLower().Contains(query) ||
            p.Name.ToLower().Contains(query));

        
        DisplayResults(results);
    }

    // Keresés árkategória alapján
    static void SearchByPriceRange()
    {
        Console.Write("Minimum ár (Ft): ");
        var minPrice = decimal.Parse(Console.ReadLine());

        Console.Write("Maximum ár (Ft): ");
        var maxPrice = decimal.Parse(Console.ReadLine());

        // Szűrés az ár alapján
        var results = parts.Where(p => p.Price >= minPrice && p.Price <= maxPrice);
        DisplayResults(results);
    }

    // Statisztika készítése egy adott típus alapján
    static void ShowStatistics()
    {
        Console.Write("Alkatrész típusa (pl. CPU, GPU): ");
        var type = Console.ReadLine().ToUpper();

        // Alkatrészek csoportosítása név szerint
        var typeStats = parts
            .Where(p => p.Type.ToUpper() == type)
            .GroupBy(p => p.Name.Split(' ')[0])
            .ToDictionary(g => g.Key, g => g.Count());

        Console.WriteLine($"\nStatisztika {type} típushoz:");
        foreach (var stat in typeStats)
        {
            Console.WriteLine($"{stat.Key}: {stat.Value} db");
        }
    }

    // Kedvezmény alkalmazása az árakra
    static void ApplyDiscount()
    {
        Console.Write("Alkatrész típusa (vagy MIND minden termékhez): ");
        var type = Console.ReadLine().ToUpper();

        Console.Write("Kedvezmény százalékban: ");
        var discount = decimal.Parse(Console.ReadLine());

        // Kedvezmény alkalmazása 
        foreach (var part in parts)
        {
            if (type == "MIND" || part.Type.ToUpper() == type)
            {
                part.Price = part.Price * (1 - discount / 100);
            }
        }

        // Módosított árak mentése
        SaveParts();
        Console.WriteLine("Kedvezmény sikeresen alkalmazva!");
    }

    // Keresési találatok megjelenítése
    static void DisplayResults(IEnumerable<ComputerPart> results)
    {
        Console.WriteLine("\nTalált alkatrészek:");
        foreach (var part in results)
        {
            Console.WriteLine($"Típus: {part.Type}, Név: {part.Name}, " +
                            $"Paraméterek: {part.Parameters}, Ár: {part.Price:N0} Ft");
        }
    }
}
